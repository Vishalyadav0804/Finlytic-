<?php
session_start();
$prin = $_SESSION['money'];
$time = $_SESSION['time'];

$servername = "localhost";
$username = "id12860777_localhost";
$password = "password";
$dbname = "id12860777_hackbvicam";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$bname = Array();
$interest = Array();

$query = $conn->query("SELECT * FROM fd");

while($result = $query->fetch_assoc()){
    $bname[] = $result['name'];
    $interest[] = $result['percentage'];
}
function total($p,$r,$t){
    $a = (1+($r/(100*12)));
    $result = ($p*(($a)**($t*12)));
    return round($result,2);
}

$total_amt = Array();

for($i=0;$i<10;$i++){
    $total_amt[$i] = total($prin,$interest[$i],$time);
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>FD</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Animated-Pretty-Product-List-v12.css?h=284bf3eeb540ed89305c95d93a10fcae">
    <link rel="stylesheet" href="assets/css/Animated-Scrolled-Down-Heading.css?h=a3c9aaed8e87e6393f589dd13584190e">
    <link rel="stylesheet" href="assets/css/Bold-BS4-Animated-Back-To-Top.css?h=71c390a8c1d1a4f985c2413ae3e254e7">
    <link rel="stylesheet" href="assets/css/Card-1.css?h=990dcc92d8695651bfca9e9623b7dc38">
    <link rel="stylesheet" href="assets/css/Card.css?h=990dcc92d8695651bfca9e9623b7dc38">
    <link rel="stylesheet" href="assets/css/dh-card-image-left-dark.css?h=fbeb7871206b72100c90953ca6cc43cc">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css?h=cabc25193678a4e8700df5b6f6e02b7c">
    <link rel="stylesheet" href="assets/css/gradient-navbar-1.css?h=4ae15b76681e1b1288bcefd94a110111">
    <link rel="stylesheet" href="assets/css/gradient-navbar.css?h=4ae15b76681e1b1288bcefd94a110111">
    <link rel="stylesheet" href="assets/css/Lista-Productos-Canito.css?h=5a5840b6e5155a118fccd8988ee61504">
    <link rel="stylesheet" href="assets/css/Loading-Div.css?h=add328231628c412362abcd8b88deb97">
    <link rel="stylesheet" href="assets/css/MUSA_timeline-1.css?h=5b292c7282fb394d2a878c18a187b9ce">
    <link rel="stylesheet" href="assets/css/MUSA_timeline.css?h=cd2c701486d10ea9cab48e0f544a5ef5">
    <link rel="stylesheet" href="assets/css/styles.css?h=d41d8cd98f00b204e9800998ecf8427e">
    <link rel="stylesheet" href="assets/css/Bootstrap-4---Table-Fixed-Header.css?h=60f9a0e3b86eedb4f061f536ff5fc611">
    <link rel="stylesheet" href="assets/css/Bootstrap-DataTables.css?h=2d89a9f440b906718c82e686151ef7b5">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" crossorigin="anonymous">
</head>

<body>
    <!-- Start: gradient-navbar -->
    <nav class="navbar navbar-dark navbar-expand-md" id="app-navbar">
        <div class="container-fluid"><a class="navbar-brand" href="/index.html"><img src="/assets/img/finlytics.png" style="height: 60px; width: 110px; border-radius: 20%;"></a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div
                class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="/index.html">Homepage</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link active" href="/calculator/index.html">Calculator</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="#">Stock Market</a></li>
                </ul>
        </div>
        </div>
    </nav>
    <!-- End: gradient-navbar -->
        <!-- Start: Bootstrap DataTables --><div class="bootstrap_datatables">
<div class="container py-5">
  <header class="text-center text-black">
    <h1 class="display-4">Top 10 Fixed Deposit Results</h1>
  </header>
  <div class="row py-5">
    <div class="col-lg-12 mx-auto">
      <div class="card rounded shadow border-0">
        <div class="card-body p-5 bg-white rounded">
          <div class="table-responsive">
            <table id="example" style="width:100%" class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Bank Name</th>
                  <th>Capital</th>
                  <th>Percentage</th>
                  <th>Maturity Amount(in Years)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php echo $bname[0];?></td>
                  <td><?php echo $prin;echo " ₹";?></td>
                  <td><?php echo $interest[0];echo " %";?></td>
                  <td><?php echo $total_amt[0];echo " ₹";?></td>
                </tr>
                <tr>                  
                <td><?php echo $bname[1];?></td>
                  <td><?php echo $prin;echo " ₹";?></td>
                  <td><?php echo $interest[1];echo " %";?></td>
                  <td><?php echo $total_amt[1];echo " ₹";?></td>                
                </tr>
                <tr>                  
                <td><?php echo $bname[2];?></td>
                  <td><?php echo $prin;echo " ₹";?></td>
                  <td><?php echo $interest[2];echo " %";?></td>
                  <td><?php echo $total_amt[2];echo " ₹";?></td>  
                </tr>
                <tr>                  
                <td><?php echo $bname[3];?></td>
                  <td><?php echo $prin;echo " ₹";?></td>
                  <td><?php echo $interest[3];echo " %";?></td>
                  <td><?php echo $total_amt[3];echo " ₹";?></td>           
                </tr>
                <tr>                  
                <td><?php echo $bname[4];?></td>
                  <td><?php echo $prin;echo " ₹";?></td>
                  <td><?php echo $interest[4];echo " %";?></td>
                  <td><?php echo $total_amt[4];echo " ₹";?></td>            
                </tr>
                <tr>                  
                <td><?php echo $bname[5];?></td>
                  <td><?php echo $prin;echo " ₹";?></td>
                  <td><?php echo $interest[5];echo " %";?></td>
                  <td><?php echo $total_amt[5];echo " ₹";?></td>     
                </tr>
                <tr>                                    
                  <td><?php echo $bname[6];?></td>
                  <td><?php echo $prin;echo " ₹";?></td>
                  <td><?php echo $interest[6];echo " %";?></td>
                  <td><?php echo $total_amt[6];echo " ₹";?></td>
                </tr>
                <tr>                  
                  <td><?php echo $bname[7];?></td>
                  <td><?php echo $prin;echo " ₹";?></td>
                  <td><?php echo $interest[7];echo " %";?></td>
                  <td><?php echo $total_amt[7];echo " ₹";?></td></tr>
                <tr>                                    
                  <td><?php echo $bname[8];?></td>
                  <td><?php echo $prin;echo " ₹";?></td>
                  <td><?php echo $interest[8];echo " %";?></td>
                  <td><?php echo $total_amt[8];echo " ₹";?></td>
                </tr>
                <tr>                                    
                  <td><?php echo $bname[9];?></td>
                  <td><?php echo $prin;echo " ₹";?></td>
                  <td><?php echo $interest[9];echo " %";?></td>
                  <td><?php echo $total_amt[9];echo " ₹";?></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
    <!-- Start: Footer Dark -->
       <div class="footer-dark">
        <footer>
            <div class="container">
                <div class="row">
                    <!-- Start: Services -->
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Services</h3>
                        <ul>
                            <li><a href="/calculator/index.html">SIP Calculator</a></li>
                            <li><a href="/calculator/index.html">Lump - Sum Calculator</a></li>
                            <li><a href="/calculator/index.html">Fixed Deposit</a></li>
                            <li><a href="/stocks/index.php">Stock Market</a></li>
                        </ul>
                    </div>
                    <!-- End: Services -->
                    <!-- Start: About -->
                    <div class="col-sm-6 col-md-3 item">
                        <h3>About</h3>
                        <ul>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Careers</a></li>
                        </ul>
                    </div>
                    <!-- End: About -->
                    <!-- Start: Footer Text -->
                    <div class="col-md-6 item text">
                        <h3>Finlytics</h3>
                        <p>Finance, simplified.</p>
                    </div>
                    <!-- End: Footer Text -->
                    <!-- Start: Social Icons -->
                    <div class="col item social"><a href="https://www.facebook.com/"><i class="icon ion-social-facebook"></i></a><a href="https://twitter.com/"><i class="icon ion-social-twitter"></i></a><a href="https://www.instagram.com/"><i class="icon ion-social-instagram"></i></a></div>
                    <!-- End: Social Icons -->
                </div>
                <!-- Start: Copyright -->
                <p class="copyright">Finlytics © 2020<a class="cd-top js-cd-top cd-top--fade-out cd-top--show" style="background-image:url(&quot;assets/img/cd-top-arrow.svg&quot;);" href="#0">Top</a></p>
                <!-- End: Copyright -->
            </div>
        </footer>
    </div>
    <!-- End: Footer Dark -->
    <!-- Start: Bold BS4 Animated Back To Top --><a class="cd-top js-cd-top cd-top--fade-out cd-top--show" style="background-image:url(&quot;assets/img/cd-top-arrow.svg?h=8ddf7d7825fadaa967dd9c80c16a380f&quot;);" href="#0">Top</a>
    <!-- End: Bold BS4 Animated Back To Top -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/Animated-Pretty-Product-List-v12.js?h=126721da17a1ceb6064324876d4733dc"></script>
    <script src="assets/js/Animated-Scrolled-Down-Heading.js?h=71ac89be0ad6dc2bf4d2c3340f47d6c1"></script>
    <script src="assets/js/Bold-BS4-Animated-Back-To-Top.js?h=25fe335c21086050d7d683aa1d563dd6"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
    <script src="assets/js/Bootstrap-DataTables.js?h=ae06441082f660b204a3db1fc70b2970"></script>
</body>

</html>