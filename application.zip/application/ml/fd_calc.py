import sys
import numpy as np
import pandas as pd
import seaborn as sns

import csv
with open('hello.csv', 'r') as file:
    reader = csv.reader(file)

reader=reader.values

y=[]
for i in range (reader.shape[0]):
  y.append(reader[i][1:])
y=np.array(y)

avgs=[]
for i in range (y.shape[0]):
  avgs.append(np.mean(y[i]))
avgs=np.array(avgs)

predic=[]
div=0
for i in range (reader.shape[0]):
  sum=0
  div=0
  # last 6 months
  for j in range (y.shape[1]-6,y.shape[1]): 
    sum=sum+y[i][j]
    div=div+1
  # this month in previos years
  for j in range (y.shape[1]-1,0,-12):
    sum=sum+y[i][j]
    div=div+1

  predic.append(sum/div)
  
predic=np.array(predic)

diff=[]
for i in range (y.shape[0]):
  # finding absolute difference
  diff.append(abs(predic[i]-avgs[i]))

diff=np.array(diff)

ubound=[]
for i in range (predic.shape[0]):
  ubound.append(predic[i] + diff[i])

ubound=np.array(ubound)

dictu={}
for i in range(ubound.shape[0]):
  dictu[i]=ubound[i]

hvalue = sorted(dictu.items(), key = lambda kv:(kv[1], kv[0]))
hvalue=np.array(hvalue)

for i in range (hvalue.shape[0]-1,hvalue.shape[0]-11,-1):
  print(reader[int(hvalue[i][0])][0],hvalue[i][1])

