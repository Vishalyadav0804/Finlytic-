<?php
session_start();
if(isset($_GET['submit'])){
    $capital = $_GET['amount'];
    $duration = $_GET['time'];
}
$_SESSION['money'] = $capital;
$_SESSION['time'] = $duration;
header('Location:/result_display/fd_result.php');
?>