<?php
session_start();
if(isset($_GET['submit'])){
    $capital = $_GET['amount'];
}

$_SESSION['money'] = $capital;

header('Location:/result_display/sip_result.php');
?>