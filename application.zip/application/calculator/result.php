<?php
session_start();
$capital = $_SESSION['capital'];
$interest = $_SESSION['interest'];
$total = $_SESSION['total'];
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>finkr_5</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Animated-Pretty-Product-List-v12.css?h=284bf3eeb540ed89305c95d93a10fcae">
    <link rel="stylesheet" href="assets/css/Animated-Scrolled-Down-Heading.css?h=a3c9aaed8e87e6393f589dd13584190e">
    <link rel="stylesheet" href="assets/css/Bold-BS4-Animated-Back-To-Top.css?h=71c390a8c1d1a4f985c2413ae3e254e7">
    <link rel="stylesheet" href="assets/css/Card-1.css?h=990dcc92d8695651bfca9e9623b7dc38">
    <link rel="stylesheet" href="assets/css/Card.css?h=990dcc92d8695651bfca9e9623b7dc38">
    <link rel="stylesheet" href="assets/css/dh-card-image-left-dark.css?h=fbeb7871206b72100c90953ca6cc43cc">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css?h=cabc25193678a4e8700df5b6f6e02b7c">
    <link rel="stylesheet" href="assets/css/gradient-navbar-1.css?h=4ae15b76681e1b1288bcefd94a110111">
    <link rel="stylesheet" href="assets/css/gradient-navbar.css?h=4ae15b76681e1b1288bcefd94a110111">
    <link rel="stylesheet" href="assets/css/Lista-Productos-Canito.css?h=5a5840b6e5155a118fccd8988ee61504">
    <link rel="stylesheet" href="assets/css/Loading-Div.css?h=add328231628c412362abcd8b88deb97">
    <link rel="stylesheet" href="assets/css/MUSA_timeline-1.css?h=5b292c7282fb394d2a878c18a187b9ce">
    <link rel="stylesheet" href="assets/css/MUSA_timeline.css?h=cd2c701486d10ea9cab48e0f544a5ef5">
    <link rel="stylesheet" href="assets/css/styles.css?h=d41d8cd98f00b204e9800998ecf8427e">
</head>

<body>
    <!-- Start: gradient-navbar -->
    <nav class="navbar navbar-dark navbar-expand-md" id="app-navbar">
        <div class="container-fluid"><a class="navbar-brand" href="#"><i class="icon ion-ios-infinite" id="brand-logo"></i></a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div
                class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item" role="presentation"><a class="nav-link active" href="#">First Item</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="#">Second Item</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="#">Third Item</a></li>
                </ul>
        </div>
        </div>
    </nav>
    <!-- End: gradient-navbar -->
    <!-- Start: Cinel cursos heading KA -->
    <h1 class="display-1 text-uppercase text-center text-primary border rounded-0" style="padding: 10px 0px;padding-top: 10px;">CINEL CURSOS</h1>
    <!-- End: Cinel cursos heading KA -->

<!-- Start: content -->

<br>Capital: <?php echo $capital;?>
<br>Intrest: <?php echo $interest;?>
<br>Total: <?php echo $total;?>



<!-- End: Content -->



    <!-- Start: Footer Dark -->
    <div class="footer-dark">
        <footer>
            <div class="container">
                <div class="row">
                    <!-- Start: Services -->
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Services</h3>
                        <ul>
                            <li><a href="#">Web design</a></li>
                            <li><a href="#">Development</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <!-- End: Services -->
                    <!-- Start: About -->
                    <div class="col-sm-6 col-md-3 item">
                        <h3>About</h3>
                        <ul>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Careers</a></li>
                        </ul>
                    </div>
                    <!-- End: About -->
                    <!-- Start: Footer Text -->
                    <div class="col-md-6 item text">
                        <h3>Company Name</h3>
                        <p>Praesent sed lobortis mi. Suspendisse vel placerat ligula. Vivamus ac sem lacus. Ut vehicula rhoncus elementum. Etiam quis tristique lectus. Aliquam in arcu eget velit pulvinar dictum vel in justo.</p>
                    </div>
                    <!-- End: Footer Text -->
                    <!-- Start: Social Icons -->
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
                    <!-- End: Social Icons -->
                </div>
                <!-- Start: Copyright -->
                <p class="copyright">Company Name © 2017</p>
                <!-- End: Copyright -->
            </div>
        </footer>
    </div>
    <!-- End: Footer Dark -->
    <!-- Start: Bold BS4 Animated Back To Top --><a class="cd-top js-cd-top cd-top--fade-out cd-top--show" style="background-image:url(&quot;assets/img/cd-top-arrow.svg?h=8ddf7d7825fadaa967dd9c80c16a380f&quot;);" href="#0">Top</a>
    <!-- End: Bold BS4 Animated Back To Top -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/Animated-Pretty-Product-List-v12.js?h=126721da17a1ceb6064324876d4733dc"></script>
    <script src="assets/js/Animated-Scrolled-Down-Heading.js?h=71ac89be0ad6dc2bf4d2c3340f47d6c1"></script>
    <script src="assets/js/Bold-BS4-Animated-Back-To-Top.js?h=25fe335c21086050d7d683aa1d563dd6"></script>
</body>

</html>